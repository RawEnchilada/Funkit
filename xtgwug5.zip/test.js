let mongoClient = require('mongodb').MongoClient;

let url = 'mongodb://localhost:27017';

mongoClient.connect(url,(err,client)=>{
    const db = client.db('local');
    let coll = db.collection('users');

    /* print all entries
    coll.find({}).toArray((err,docs)=>{
        console.log(docs);
    });*/

    //Modify one entry
    /*coll.updateOne({
        "username":"alice",
        "password":"lol",
        "sessionid":"none"
    }, {$set: {
        "username":"alice",
        "password":"lol",
        "account":"admin",
        "sessionid":"none"
    }},
    (eerr,result)=>{
        console.log("should be done");
    });*/
    

    client.close();
});